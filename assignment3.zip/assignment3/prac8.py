import numpy as np

sales = np.array([
    [120, 150, 135, 170],
    [80, 95, 110, 105],
    [200, 180, 220, 240]
])


product_total = sales.sum(axis=1)
print("Total sales of each product:", product_total)


month_total = sales.sum(axis=0)
print("Total sales of each month:", month_total)


highest_product = np.argmax(product_total)
print("Product with highest sales: Product", highest_product + 1)


lowest_month = np.argmin(month_total)
print("Month with lowest sales: Month", lowest_month + 1)


modified = sales.copy()
modified[modified < 100] = 0

print("Original array:")
print(sales)

print("Modified array:")
print(modified)