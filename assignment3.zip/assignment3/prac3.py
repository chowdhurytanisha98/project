numbers = [12, 7, -4, 12, 18, 5, -3, 8, 18]

non_negative = []
unique = []

even_sum = 0
negative_count = 0

for num in numbers:

    if num < 0:
        negative_count = negative_count + 1
        continue

    non_negative.append(num)

    if num not in unique:
        unique.append(num)

    if num % 2 == 0:
        even_sum = even_sum + num

print("Non-negative values:", non_negative)
print("Unique non-negative values:", unique)
print("Sum of even non-negative numbers:", even_sum)
print("Number of negative numbers:", negative_count)
print("Elements at indices 1, 3, 5 and 7:", numbers[1:8:2])