sales = [
    {"product": "Pen", "quantity": 3, "price": 15},
    {"product": "Book", "quantity": 2, "price": 120},
    {"product": "Pen", "quantity": 5, "price": 15},
    {"product": "Bag", "quantity": 1, "price": 850},
    {"product": "Book", "quantity": -1, "price": 120},
    {"product": "Ruler", "quantity": 4, "price": 20}
]

revenue = {}
high_revenue = []
total_revenue = 0
invalid = 0

for sale in sales:

    product = sale["product"]
    quantity = sale["quantity"]
    price = sale["price"]

    if quantity <= 0 or price < 0:
        invalid += 1
        continue

    amount = quantity * price

    if product in revenue:
        revenue[product] = revenue[product] + amount
    else:
        revenue[product] = amount

    total_revenue = total_revenue + amount

    if amount >= 200:
        high_revenue.append(product)

highest_product = max(revenue, key=revenue.get)

print("Product revenue:", revenue)
print("Total revenue:", total_revenue)
print("Highest revenue product:", highest_product)
print("High revenue transactions:", high_revenue)
print("Invalid records:", invalid)