marks = [88, 74, 93, -5, 61, 47, 105, 82, 59]

valid_marks = []

grades = {"A": 0, "B": 0, "C": 0, "F": 0}

for mark in marks:
    if mark < 0 or mark > 100:
        continue

    valid_marks.append(mark)

    if mark >= 80:
        grades["A"] += 1
    elif mark >= 70:
        grades["B"] += 1
    elif mark >= 60:
        grades["C"] += 1
    else:
        grades["F"] += 1

average = sum(valid_marks) / len(valid_marks)

print("Valid marks:", valid_marks)
print("Grade counts:", grades)
print("Average:", round(average, 2))