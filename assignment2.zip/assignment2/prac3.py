stock = {
    "pen": 12,
    "book": 3,
    "bag": 2,
    "ruler": 9,
    "calculator": 1
}

total = 0
low_stock = {}

for item in stock:
    total = total + stock[item]

    if stock[item] < 5:
        low_stock[item] = stock[item]

print("Total units:", total)
print("Low stock:", low_stock)