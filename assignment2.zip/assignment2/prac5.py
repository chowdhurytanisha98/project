delivery_1 = {"pen": 12, "book": 5, "bag": 2}
delivery_2 = {"book": 4, "ruler": 10, "pen": 3}

combined = {}

for item in delivery_1:
    combined[item] = delivery_1[item]

for item in delivery_2:
    if item in combined:
        combined[item] = combined[item] + delivery_2[item]
    else:
        combined[item] = delivery_2[item]

total = 0

for item in combined:
    total = total + combined[item]

print("Combined delivery:", combined)
print("Grand total:", total)