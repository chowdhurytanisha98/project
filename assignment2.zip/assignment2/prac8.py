scores = {
    "Amina": {"python": 82, "statistics": 76, "calculus": 88},
    "Maya": {"python": 58, "statistics": 64, "calculus": 61},
    "Disha": {"python": 91, "statistics": 89, "calculus": 94},
    "Nora": {"python": 45, "statistics": 52, "calculus": 56}
}

results = {}

for student in scores:
    total = 0

    for subject in scores[student]:
        total = total + scores[student][subject]

    average = total / 3

    if average >= 60:
        status = "Pass"
    else:
        status = "Fail"

    results[student] = {
        "average": round(average, 2),
        "status": status
    }

highest = 0
top_student = ""

for student in results:
    if results[student]["average"] > highest:
        highest = results[student]["average"]
        top_student = student

print("Results:", results)
print("Highest average:", top_student, highest)